package com.example.supashopa_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.view.View.GONE;

public class shoppingActivity extends AppCompatActivity implements OnItemClickInterface, View.OnClickListener {
RecyclerView recyclerView, searchRecyclerview;
ProgressBar progressBar;
Button cart, logout;
TextView textView;
SearchView searchView;
Toolbar toolbar;

JSONArray jsonArray;
private RecyclerviewAdapter adapter;
private ArrayList<Items> itemsArrayList;
ArrayList<Items> itemsArrayList1 =null;
public static ArrayList<String> cartitems;
private int[] deactivateditems =new int[0];//used to deactivate items already in cart
    private String shop;
    JSONArray shopname;
    SharedPreferences mySP;
    SharedPreferences.Editor mySPEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mySP=getSharedPreferences("MySharedPref", MODE_PRIVATE);
        mySPEditor=mySP.edit();

        //checking whether a user has logged in.
        if (!(mySP.contains("phone")&& mySP.contains("password"))){
            Intent intent=new Intent(this, signUpActivity.class);
            startActivity(intent);
            finish();
        }//method to check whether the user is logged in

        setContentView(R.layout.activity_shopping);

        androidx.appcompat.widget.Toolbar myToolbar= findViewById(R.id.appbar);
        myToolbar.setTitle("");
        myToolbar.bringToFront();
        setSupportActionBar(myToolbar);
        searchView=findViewById(R.id.search_items);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                itemsSearch(query);
                for (int i=0; i<itemsArrayList.size(); i++) {

                    if (itemsArrayList.get(i).getProductname().contains(query)) {
                        Toast.makeText(getApplicationContext(), "query found", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "query not found", Toast.LENGTH_SHORT).show();
                    }
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
       recyclerView=findViewById(R.id.rvshoppingitems);
       searchRecyclerview=findViewById(R.id.rvshoppingitems);
       progressBar=findViewById(R.id.progressbar);
       textView=findViewById(R.id.tvitems);
       cart =findViewById(R.id.cart);
       cart.setOnClickListener(this);
       logout=findViewById(R.id.logout);
      // logout.setOnClickListener(this);
       itemsArrayList=new ArrayList<>();
       cartitems= new ArrayList<>();
      cart.setText(String.valueOf(cartitems.size()));

        productsrequest();//method to get items for display is called inside onCreate method.
    }

    public void itemsSearch(final String query){
        itemsArrayList1 =new ArrayList<>();
        StringRequest stringRequest=new StringRequest(Request.Method.POST, Constants.URL_SEARCHITEMS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        recyclerView.setVisibility(View.VISIBLE);
                        try {
                            JSONArray jsonArray=new JSONArray(response);
                            for (int i=0; i<jsonArray.length(); i++){
                                JSONObject jsonObject=jsonArray.getJSONObject(i);
                                int itemid = jsonObject.getInt("product_id");
                                String itemname = jsonObject.getString("name");
                                String itemimage = jsonObject.getString("product_picture");
                                String price = jsonObject.getString("unit_price");
                                String category = jsonObject.getString("category");

                                itemsArrayList1.add(new Items(itemid,itemname,itemimage,price,category));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        buildRecyclerView(itemsArrayList1, deactivateditems,searchRecyclerview);
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<>();
                params.put("query", "%"+query+"%");
                params.put("shopDbName", Constants.shopDbName);
                return params;
            }
        };
        requesthandler.getInstance(this).addTorequestQueue(stringRequest);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.profile:
                Toast.makeText(this, item.getTitle()+" selected", Toast.LENGTH_LONG).show();
                return true;

            case R.id.logout:
                AlertDialog.Builder builder=new AlertDialog.Builder(shoppingActivity.this);
                builder.setMessage("Do you want to logout?");
                builder.setTitle("logout");
                builder.setCancelable(false);
                builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mySPEditor.remove("phone");
                        mySPEditor.remove("password");
                        mySPEditor.remove("user_id");
                        mySPEditor.commit();
                        if (!(mySP.contains("phone")&&mySP.contains("password")&&mySP.contains("user_id"))){
                            Toast.makeText(getApplicationContext(), "logged out!", Toast.LENGTH_SHORT).show();
                            Intent intent=new Intent(getApplicationContext(), login.class);
                            startActivity(intent);
                            finish();
                        }

                    }

                });
                builder.setNegativeButton("no", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog alert=builder.create();
                alert.show();
                if (!(mySP.contains("phone")&&mySP.contains("password"))) {
                    Toast.makeText(getApplicationContext(),"logged out",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(this,signUpActivity.class);
                    startActivity(intent);
                }
                return true;

                default:
                    return super.onOptionsItemSelected(item);
        }
    }

    private void productsrequest() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_FETCHITEMS,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressBar.setVisibility(GONE);
                recyclerView.setVisibility(View.VISIBLE);
               // Toast.makeText(shoppingActivity.this, Constants.shopDbName, Toast.LENGTH_SHORT).show();

                try {
                    jsonArray=new JSONArray(response);

                    for (int i=0;i<response.length();i++){

                        JSONObject jsonObject = new JSONObject(jsonArray.getString(i));
                        int itemid = jsonObject.getInt("product_id");
                        String itemname = jsonObject.getString("name");
                        String itemimage = jsonObject.getString("product_picture");
                        String price = jsonObject.getString("unit_price");
                        String category = jsonObject.getString("category");

                        itemsArrayList.add(new Items(itemid, itemname, itemimage, price, category));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                buildRecyclerView(itemsArrayList,deactivateditems,recyclerView);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), ""+error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<>();
                params.put("shop_name", Constants.shopDbName);
                return params;
            }
        };
        requesthandler.getInstance(this).addTorequestQueue(stringRequest);

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(3000, 10, 2));
    }//method to get items from remote source.

    private void buildRecyclerView(ArrayList<Items> rvItems, int[] deactivateItems,RecyclerView recyclerView){
        adapter=new RecyclerviewAdapter(rvItems, shoppingActivity.this,this,deactivateItems);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(adapter);
    }//method to build the items display recyclerview

    @Override
    public void onClickAddItemtoCart(int productId,int numberofitems) {

        try {
           for (int i=0; i<jsonArray.length(); i++){
                if(jsonArray.getJSONObject(i).getInt("product_id")==productId){
                    cartitems.add((jsonArray.getJSONObject(i).put("quantity", numberofitems)).toString());
                }
            }
           // cartitems.add((jsonArray.getJSONObject(productId).put("quantity",numberofitems)).toString());
            cart.setText(String.valueOf(cartitems.size()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }//method to handle adding an item to the cart

    @Override
    public void changeCartItems(int position, int quantity) {
        try {
            JSONObject jsonObject=new JSONObject(cartitems.get(position));
            cartitems.remove(position);
            jsonObject.put("quantity", quantity);
            cartitems.add(position,jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }//method to handle changes in quantity of cart items

    @Override
    public void removecartitem(int index) {

    }//method to remove an item from cart. not functional for this activity

    @Override
    public void setTotal(ArrayList arrayList) {

    }//not functional for this class

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.cart:
        Intent intent=new Intent(getApplicationContext(),cartActivity.class);
        intent.putStringArrayListExtra("cart items",cartitems);
        intent.putExtra("shop", shop);
        startActivityForResult(intent,2);
        break;
            case R.id.logout:
                mySPEditor.remove("phone");
                mySPEditor.remove("password");
                mySPEditor.commit();

                if (!(mySP.contains("phone")&&mySP.contains("password"))) {
                    Toast.makeText(getApplicationContext(),"logged out",Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.search_items:


        }
    }//handling button clicks

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==2){
           cartitems.clear();
            ArrayList<String> arrayList=data.getStringArrayListExtra("cart items");
            cartitems=arrayList;
            cart.setText("0");
            deactivateditems=new int[arrayList.size()];
            for (int i=0; i<arrayList.size(); i++){
                try {
                    JSONObject jsonObject=new JSONObject(arrayList.get(i));
                    for (int x=0; x<itemsArrayList.size();x++){
                        if (jsonObject.getInt("product_id")==itemsArrayList.get(x).getProductid()){
                            deactivateditems[i]=x;
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            buildRecyclerView(itemsArrayList,deactivateditems, recyclerView);
        }else if (requestCode==3){
            shop=data.getStringExtra("shopDbName");
            Toast.makeText(getApplicationContext(), shop, Toast.LENGTH_SHORT).show();
        }
    }//method to sychronize shopping activity with the cart

    @Override
    protected void onResume() {
        super.onResume();
        cart.setText(String.valueOf(cartitems.size()));
        if (itemsArrayList.size()<1){
            //productsrequest();
        }

    }

    @Override
    public void onBackPressed() {
        if (!(itemsArrayList1 ==null)) {
            buildRecyclerView(itemsArrayList, deactivateditems, recyclerView);
            searchView.clearFocus();
            itemsArrayList1.clear();
            itemsArrayList1 =null;
        }else {
            Intent intent=new Intent(this, ShopsActivity.class);
            startActivity(intent);
            finish();
        }
    }

}
