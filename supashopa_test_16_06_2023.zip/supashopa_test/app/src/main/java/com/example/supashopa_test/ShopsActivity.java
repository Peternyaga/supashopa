package com.example.supashopa_test;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ShopsActivity extends AppCompatActivity implements View.OnClickListener {
    ArrayList<ShopDetails> shops=new ArrayList<>();
    JSONArray jsonArray;
    RecyclerView shopsRecyclerView;
    ProgressBar progressBar;
    LinearLayout networkError;
    TextView refresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shops);
        shopsRecyclerView=findViewById(R.id.rv_shops);
        progressBar=findViewById(R.id.progressbar);
        networkError=findViewById(R.id.networkerror);
        refresh=findViewById(R.id.tvrefresh);
        refresh.setOnClickListener(this);
        getShops();
       // Toast.makeText(this, "shops length: "+getShops().size(), Toast.LENGTH_SHORT).show();
    }
    private ArrayList getShops(){
        StringRequest stringRequest=new StringRequest(Request.Method.GET, Constants.URL_SHOPS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressBar.setVisibility(View.GONE);
                //Toast.makeText(ShopsActivity.this, response, Toast.LENGTH_SHORT).show();
                try {
                    jsonArray=new JSONArray(response);

                    for (int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject=new JSONObject(jsonArray.getJSONObject(i).toString());
                        String shopName=jsonObject.getString("shop name");
                        String shopDescription=jsonObject.getString("shop description");
                        String shopPicURL=jsonObject.getString("shop image URL");
                        String databaseName=jsonObject.getString("database name");
                        float shopRating= (float) jsonObject.getDouble("shop rating");

                        shops.add(new ShopDetails(shopName,shopDescription, shopPicURL, databaseName ,shopRating));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                buildShopsRecyclerView();


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(ShopsActivity.this, "Cannot get shops at the moment. Try again later", Toast.LENGTH_SHORT).show();
                networkError.setVisibility(View.VISIBLE);

            }
        });
        requesthandler.getInstance(this).addTorequestQueue(stringRequest);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(3000, 10, 2));

        shopsRecyclerView.setVisibility(View.VISIBLE);
        shopsRecyclerView.bringToFront();
        return shops;
    }

    private void buildShopsRecyclerView() {

        ShopsRecyclerviewAdapter adapter = new ShopsRecyclerviewAdapter(shops, ShopsActivity.this);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        shopsRecyclerView.setHasFixedSize(true);
        shopsRecyclerView.setLayoutManager(linearLayoutManager);
        shopsRecyclerView.setAdapter(adapter);
    }


    @Override
    public void onClick(View v) {
        progressBar.setVisibility(View.VISIBLE);
        networkError.setVisibility(View.GONE);
        getShops();
    }
}
