package com.example.supashopa_test;

public class Constants {
    //private static final String ROOT_URL="http://192.168.137.1/android/v1/";
    private static final String ROOT_URL=" https://d37c-196-101-188-122.ngrok-free.app/android/v1/";
    public static final String URL_REGISTER= ROOT_URL+"registeruser.php";
    public static final String URL_LOGIN=ROOT_URL+"login.php";
    public static final String URL_FETCHITEMS=ROOT_URL+"fetch_shop_items.php";
    public static final String URL_CHECKOUT=ROOT_URL+"checkout.php";
    public static  final String URL_SEARCHITEMS=ROOT_URL+"item_search.php";
    public static  final String URL_SHOPS=ROOT_URL+"fetch_Shops.php";
    public static String shopDbName;//name of the shop the user has entered;
    public static String shopName;


}
