package com.example.supashopa_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class cartActivity extends AppCompatActivity implements OnItemClickInterface,View.OnClickListener{
    RecyclerView recyclerView;
    ProgressBar progressBar;
    EditText confirmPhoneNumber;
    TextView tvtotal,progressbarmsg, checkoutTotal, checkoutShop;
    Button btncheckout, confirmCheckoutDetails;
    LinearLayoutCompat linearLayout, checkoutDetails;
    ArrayList<String> cartItems;
    ArrayList<CartItems> arrayList;
    JSONArray finalCheckoutList;
    double total;
    String shop; //name of shop database passed from shopping activity
    private CartRecyclerviewAdapter adapter;
    SharedPreferences mySP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        mySP=getSharedPreferences("MySharedPref", MODE_PRIVATE);
        recyclerView=findViewById(R.id.rvcartitems);
        progressBar=findViewById(R.id.cartprogressbar);
        linearLayout=findViewById(R.id.linearLayout);
        linearLayout.bringToFront();
        tvtotal=findViewById(R.id.tvtotal);
        progressbarmsg=findViewById(R.id.tvprogressbarmsg);
        progressbarmsg.setVisibility(View.GONE);
        btncheckout=findViewById(R.id.btncheckout);
        btncheckout.setOnClickListener(this);
        checkoutDetails=findViewById(R.id.mpesaPaymentDetails);
        confirmPhoneNumber=findViewById(R.id.et_paymentMpesaPhoneNumber);
        checkoutTotal=findViewById(R.id.tv_paymentMpesaTotal);
        checkoutShop=findViewById(R.id.tv_paymentShopname);
        confirmCheckoutDetails=findViewById(R.id.btn_paymentDetailsOk);
        confirmCheckoutDetails.setOnClickListener(this);

        Intent intent=getIntent();
        cartItems=intent.getStringArrayListExtra("cart items");
        shop=intent.getStringExtra("shop");
        arrayList=new ArrayList<>();

        for (int i=0; i<cartItems.size(); i++){
            try {
                JSONObject jsonObject=new JSONObject(cartItems.get(i));
                int itemid = jsonObject.getInt("product_id");
                String itemname = jsonObject.getString("name");
                String itemimage = jsonObject.getString("product_picture");
                String price = jsonObject.getString("unit_price");
                String category = jsonObject.getString("category");
                int quantity=jsonObject.getInt("quantity");

                arrayList.add(new CartItems(itemid,itemname, itemimage, price, category, quantity));

                buildRecyclerView();
                recyclerView.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);

            } catch (JSONException e) {
                e.printStackTrace();
                tvtotal.setText(e.getMessage());
            }
        }
        setTotal(arrayList);
    }

    public void cartIsEmpty(){
        if(arrayList.size()==0){
            Toast.makeText(getApplicationContext(), "Your cart is empty!", Toast.LENGTH_SHORT).show();
            btncheckout.setEnabled(false);
            btncheckout.bringToFront();
            progressBar.setVisibility(View.GONE);
            progressbarmsg.setVisibility(View.VISIBLE);
            progressbarmsg.setText("your cart is empty!");
            progressbarmsg.bringToFront();
        }
    }

    private void checkOut(){
        try {

        final String userId=mySP.getString("userId", null);
        int id,quantity;
        JSONObject idqnty;
        finalCheckoutList=new JSONArray();
        for (int i=0; i<arrayList.size(); i++){
            idqnty=new JSONObject();
            id=arrayList.get(i).getProductid();
            quantity=arrayList.get(i).getQuantity();
                idqnty.put("item id",id);
                idqnty.put("quantity", quantity);

                finalCheckoutList.put(idqnty);
        }
        final String finalItems=finalCheckoutList.toString();
        //Double total;

        final StringRequest stringRequest=new StringRequest(Request.Method.POST, Constants.URL_CHECKOUT, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressBar.setVisibility(View.GONE);
                //progressbarmsg.setVisibility(View.GONE);
                progressbarmsg.setText(response);
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    if(jsonObject.getInt("code")==0){
                        arrayList.clear();
                        AlertDialog.Builder builder=new AlertDialog.Builder(cartActivity.this);
                        builder.setMessage("your order has been received. you will be notified once your package is ready");
                        builder.setTitle("Order Received");
                        builder.setCancelable(false);
                        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                    Intent intent=new Intent(getApplicationContext(), shoppingActivity.class);
                                    intent.putExtra("shopDbName", Constants.shopDbName);
                                    startActivity(intent);
                                    finish();
                                }

                        });

                        AlertDialog alert=builder.create();
                        alert.show();
                        Snackbar.make(btncheckout,jsonObject.getString("message")+ ". You will be notified once your package is ready. \n THANK YOU FOR SHOPPING WITH US!!", Snackbar.LENGTH_LONG).show();


                    }else {
                        btncheckout.setEnabled(true);
                        Toast.makeText(cartActivity.this, "An error occured. Please try again", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(cartActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                //Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();

            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("userId", String.valueOf(userId));
                params.put("total", String.valueOf((int)total));
                params.put("items", finalItems);
                params.put("shop", Constants.shopDbName);
                params.put("phone_number", "0759265709");
                return params;
                //return super.getParams();
            }
        };
            requesthandler.getInstance(this).addTorequestQueue(stringRequest);

        } catch (JSONException e) {
                e.printStackTrace();
            }
    }

    @Override
    public void setTotal(ArrayList<CartItems> arrayList){
        cartIsEmpty();
        total=0.00;
        tvtotal.setText("KSh. "+ total);

        for (int i=0; i<arrayList.size();i++) {
            total += arrayList.get(i).getQuantity() * Double.parseDouble(arrayList.get(i).getPrice());
        }
        DecimalFormat decimalFormat=new DecimalFormat("####.00");
        tvtotal.setText("KSh "+decimalFormat.format(total));
        tvtotal.bringToFront();
        this.arrayList=arrayList;
    }
    @Override
    public void removecartitem(int index) {
        arrayList.remove(index);
        setTotal(arrayList);
        buildRecyclerView();
    }

    private void buildRecyclerView(){
        adapter=new CartRecyclerviewAdapter(arrayList, cartActivity.this, this);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        cartItems.clear();
        JSONObject returnedItems=new JSONObject();
        Intent intent=new Intent(this, shoppingActivity.class);
        for(int i=0; i<arrayList.size(); i++){
            try {
                returnedItems.put("product_id", arrayList.get(i).getProductid());
                returnedItems.put("name", arrayList.get(i).getProductname());
                returnedItems.put("product_picture", arrayList.get(i).getProductpic_url());
                returnedItems.put("unit_price", arrayList.get(i).getPrice());
                returnedItems.put("category", arrayList.get(i).getCategory());
                returnedItems.put("quantity", arrayList.get(i).getQuantity());

                cartItems.add(returnedItems.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        intent.putStringArrayListExtra("cart items", cartItems);
        setResult(2,intent);
        finish();
    }

    @Override
    public void onClickAddItemtoCart(int position, int numberofitems) {

    }

    @Override
    public void changeCartItems(int position, int quantity) {

    }

   /* @Override
    public void setTotal(ArrayList<com.example.supashopa_test.CartItems> arrayList) {

    }*/

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btncheckout:
       /* progressbarmsg.setText("sending order...");
        progressBar.setVisibility(View.VISIBLE);
        progressbarmsg.setVisibility(View.VISIBLE);
        progressBar.bringToFront();
        progressbarmsg.bringToFront();
        recyclerView.setEnabled(false);
        btncheckout.setEnabled(false);
        checkOut();*/
                checkoutDetails.setVisibility(View.VISIBLE);
                checkoutDetails.setClickable(true);
                checkoutDetails.bringToFront();
                btncheckout.setEnabled(false);
                //checkoutDetails.requestFocus();
                recyclerView.setLayoutFrozen(true);

                confirmPhoneNumber.setText(mySP.getString("phone", ""));
                checkoutTotal.setText("KSh. " + total + "0");
                checkoutShop.setText(Constants.shopName);
                break;

            case R.id.btn_paymentDetailsOk:
                progressbarmsg.setText("sending order...");
                progressBar.setVisibility(View.VISIBLE);
                progressbarmsg.setVisibility(View.VISIBLE);
                progressBar.bringToFront();
                progressbarmsg.bringToFront();
                recyclerView.setEnabled(false);
                btncheckout.setEnabled(false);
                checkOut();
        }
    }
}
